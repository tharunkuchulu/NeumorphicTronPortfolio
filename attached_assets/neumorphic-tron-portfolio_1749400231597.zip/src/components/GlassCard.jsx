export default function GlassCard({ title, children }) {
  return (
    <div className="glass-card">
      <h3>{title}</h3>
      <div>{children}</div>
    </div>
  );
}
