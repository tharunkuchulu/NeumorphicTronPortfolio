import GlassCard from './GlassCard';

export default function Contact() {
  return (
    <GlassCard title="Contact">
      <p>Email: tharun@example.com</p>
      <button>Get in Touch</button>
    </GlassCard>
  );
}
