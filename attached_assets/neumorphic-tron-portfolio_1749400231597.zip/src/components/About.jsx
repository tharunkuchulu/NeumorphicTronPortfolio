import GlassCard from './GlassCard';

export default function About() {
  return (
    <GlassCard title="About Me">
      <p>I specialize in crafting futuristic interfaces and full-stack systems using React, FastAPI, and AWS.</p>
    </GlassCard>
  );
}
