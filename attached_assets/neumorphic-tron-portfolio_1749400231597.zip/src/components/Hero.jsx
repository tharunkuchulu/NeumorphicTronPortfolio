import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="hero-section">
      <motion.h1
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        Tharun Vankayala
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        Building futuristic web experiences.
      </motion.p>
    </section>
  );
}
