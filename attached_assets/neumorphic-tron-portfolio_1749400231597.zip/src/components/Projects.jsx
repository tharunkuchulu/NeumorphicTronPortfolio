import GlassCard from './GlassCard';

export default function Projects() {
  return (
    <GlassCard title="Projects">
      <ul>
        <li>🚀 AI Interview Simulator</li>
        <li>🎬 Movie OTT Platform</li>
        <li>📊 AWS Cost Monitor Tool</li>
      </ul>
    </GlassCard>
  );
}
