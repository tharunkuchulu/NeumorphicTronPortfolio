import GlassCard from './GlassCard';

export default function Skills() {
  return (
    <GlassCard title="Skills">
      <p>React, FastAPI, AWS, MySQL, Figma, Git</p>
    </GlassCard>
  );
}
